<!doctype html>
<html lang="en">
  <head>

    <!-- Page Title -->
    <title>Page not found | Coinomi</title>

    <!-- Global site tag (gtag.js) - Google Analytics -->
    <script async src="https://www.googletagmanager.com/gtag/js?id=UA-51412754-1"></script>
    <script>
      window.dataLayer = window.dataLayer || [];
      function gtag(){dataLayer.push(arguments);}
      gtag('js', new Date());
      gtag('config', 'UA-51412754-1');
    </script>

    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, height=device-height, initial-scale=1.0">
    <meta name="apple-mobile-web-app-capable" content="yes" />
    <meta name="keywords" content="Blockchain, Cryptocurrency, Bitcoin Wallet, Bitcoin, Ethereum, Crypto Wallet, Litecoin, Crypto, btc">

    <link rel="canonical" href="https://www.coinomi.com/404.html" />

    <!-- Meta -->
      <meta name="twitter:title" content="Coinomi: The blockchain wallet trusted by millions." />
      <meta property="og:title" content="Coinomi: The blockchain wallet trusted by millions." />
      <meta property="og:url" content="https://www.coinomi.com/en/" />
      <meta property="og:type" content="website" />
      <meta property="og:image" content="https://www.coinomi.com/img/og-image.jpg" />
      <meta property="twitter:image" content="https://www.coinomi.com/img/og-image.jpg">

    <meta name="title" content="Coinomi: The blockchain wallet trusted by millions.">
    <meta name="description" content="Seamlessly explore 10,000+ Assets &amp; NFTs Across 50+ Blockchains. Including Bitcoin, Ethereum, Solana &amp; more. Your secure, non-custodial gateway to the world of DeFi.">
    <meta property="og:description" content="Seamlessly explore 10,000+ Assets &amp; NFTs Across 50+ Blockchains. Including Bitcoin, Ethereum, Solana &amp; more. Your secure, non-custodial gateway to the world of DeFi." />
    <meta property="fb:admins" content="695746389"/>
    <meta property="fb:app_id" content="411646829332181"/>
    <meta name="twitter:card" content="summary_large_image"/>
    <meta name="twitter:creator" content="@CoinomiWallet" />
    <meta name="twitter:site" content="@CoinomiWallet" />
    <meta name="twitter:description" content="Seamlessly explore 10,000+ Assets &amp; NFTs Across 50+ Blockchains. Including Bitcoin, Ethereum, Solana &amp; more. Your secure, non-custodial gateway to the world of DeFi." />
    <meta name="twitter:app:id:googleplay" content="com.coinomi.wallet" />
    <meta name="twitter:app:id:ipad" content="1333588809" />
    <meta name="twitter:app:id:iphone" content="1333588809" />

    <!-- Favicon -->
    <link rel="apple-touch-icon" sizes="180x180" href="/apple-touch-icon.png">
    <link rel="icon" type="image/png" sizes="32x32" href="/favicon-32x32.png">
    <link rel="icon" type="image/png" sizes="16x16" href="/favicon-16x16.png">
    <link rel="manifest" href="/site.webmanifest">
    <link rel="mask-icon" href="/safari-pinned-tab.svg" color="#2f78e2">
    <meta name="msapplication-TileColor" content="#f1f1f1">
    <meta name="theme-color" content="#f1f1f1">
    <meta name = "yandex-verification" content = "6acf13c6591c28e0" />
    <meta name="msvalidate.01" content="555A06B0064F02F4A174BBCE0C9B409F" />

    <!-- Fonts -->
    <link rel="preconnect" href="https://fonts.googleapis.com">
    <link rel="preconnect" href="https://fonts.gstatic.com" crossorigin>
    <link href="https://fonts.googleapis.com/css2?family=Plus+Jakarta+Sans:ital,wght@0,200..800;1,200..800&display=swap" rel="stylesheet" type="text/css">
    <link href="https://fonts.googleapis.com/css?family=IBM+Plex+Sans:400,500,600,700&amp;subset=greek" rel="stylesheet" type="text/css"/>

    <!-- Font Awesome -->
    <script src="https://kit.fontawesome.com/d190efec3e.js"></script>

    <script>
      function initFreshChat() {
        window.fcWidget.init({
          token: "c6923244-7ded-43c8-b778-5443e3964356",
          host: "https://wchat.freshchat.com"
        });
      }
      function initialize(i,t){var e;i.getElementById(t)?initFreshChat():((e=i.createElement("script")).id=t,e.async=!0,e.src="https://wchat.freshchat.com/js/widget.js",e.onload=initFreshChat,i.head.appendChild(e))}function initiateCall(){initialize(document,"freshchat-js-sdk")}window.addEventListener?window.addEventListener("load",initiateCall,!1):window.attachEvent("load",initiateCall,!1);
    </script>
    <!-- Styles -->
    <link rel="stylesheet" href="/css/styles.css?v=2ac19e2">

    <!-- Scripts -->
    <script src="https://code.jquery.com/jquery-3.7.1.min.js"></script>

    <script src="/js/plugins.min.js?v=2ac19e2"></script>

    <script src="/js/scripts.min.js?v=2ac19e2"></script>

  </head>
  <body class="coinomi slides scroll simplifiedMobile">

    <!-- SVG Library -->
    <svg xmlns="http://www.w3.org/2000/svg" style="display:none">

      <symbol id="logo" viewBox="0 0 106 31">
        <path class="cls-1" d="M14.26,22.19V26a9.87,9.87,0,0,1-4.89,1.44A7.79,7.79,0,0,1,3.69,25,7.79,7.79,0,0,1,1.25,19.3a8.17,8.17,0,0,1,2.43-6.05,8.32,8.32,0,0,1,6.09-2.4A10.24,10.24,0,0,1,14.26,12v3.68a9,9,0,0,0-4.71-1.55A5.09,5.09,0,0,0,6,15.55a4.52,4.52,0,0,0-1.54,3.38A5.06,5.06,0,0,0,5.88,22.6,4.71,4.71,0,0,0,9.4,24.09a8.83,8.83,0,0,0,4.86-1.9Zm1.12-3.12a7.87,7.87,0,0,1,2.53-5.72,8,8,0,0,1,5.82-2.5,8.15,8.15,0,0,1,5.9,2.47,7.75,7.75,0,0,1,2.53,5.75,8.11,8.11,0,0,1-2.48,5.84A7.78,7.78,0,0,1,24,27.43a8.38,8.38,0,0,1-6-2.49,8,8,0,0,1-2.55-5.87Zm13.59,0a4.69,4.69,0,0,0-1.52-3.49,5,5,0,0,0-3.6-1.48,5.15,5.15,0,0,0-3.7,1.5,4.84,4.84,0,0,0-1.54,3.59,4.69,4.69,0,0,0,1.56,3.48,5.17,5.17,0,0,0,3.68,1.49,4.91,4.91,0,0,0,3.58-1.53A4.86,4.86,0,0,0,29,19.08Zm4.9-12.89a2.41,2.41,0,0,1,.76-1.77,2.49,2.49,0,0,1,1.81-.75,2.42,2.42,0,0,1,1.77.75A2.4,2.4,0,0,1,39,6.19a2.53,2.53,0,0,1-2.52,2.52A2.51,2.51,0,0,1,34.63,8a2.46,2.46,0,0,1-.76-1.79Zm.93,5.13h3.31V27H34.8V11.32ZM41.19,27V11.32h3.3v2.59A13.45,13.45,0,0,1,47,11.59a4.67,4.67,0,0,1,2.56-.74,5.09,5.09,0,0,1,3.6,1.4,4.49,4.49,0,0,1,1.5,3.39V27H51.4V16.6a2.89,2.89,0,0,0-.82-2.12,2.78,2.78,0,0,0-2.08-.83A3.62,3.62,0,0,0,45.67,15a5,5,0,0,0-1.18,3.38V27Zm15.53-7.89a7.87,7.87,0,0,1,2.53-5.72,8,8,0,0,1,5.82-2.5A8.15,8.15,0,0,1,71,13.32a7.75,7.75,0,0,1,2.53,5.75A8.11,8.11,0,0,1,71,24.91a7.78,7.78,0,0,1-5.72,2.52,8.38,8.38,0,0,1-6-2.49,8,8,0,0,1-2.55-5.87Zm13.59,0a4.69,4.69,0,0,0-1.52-3.49,5,5,0,0,0-3.6-1.48,5.15,5.15,0,0,0-3.7,1.5A4.84,4.84,0,0,0,60,19.2a4.69,4.69,0,0,0,1.56,3.48,5.17,5.17,0,0,0,3.68,1.49,4.91,4.91,0,0,0,3.58-1.53,4.86,4.86,0,0,0,1.54-3.56ZM75.52,27V11.32h3.3v2.36A9.72,9.72,0,0,1,81,11.53a4.34,4.34,0,0,1,2.4-.68,4.44,4.44,0,0,1,2.78.78,5.83,5.83,0,0,1,1.71,2.48,9.82,9.82,0,0,1,2.39-2.48A4.63,4.63,0,0,1,93,10.85a4.34,4.34,0,0,1,3.22,1.4,4.59,4.59,0,0,1,1.35,3.31V27h-3.3V16.38a2.29,2.29,0,0,0-2.56-2.62,3,3,0,0,0-2.48,1.33,5.33,5.33,0,0,0-1,3.31V27h-3.3V16.84c0-2.05-.83-3.08-2.5-3.08A3.14,3.14,0,0,0,79.86,15a4.7,4.7,0,0,0-1,3.1V27ZM99.91,6.19a2.41,2.41,0,0,1,.76-1.77,2.49,2.49,0,0,1,1.81-.75,2.42,2.42,0,0,1,1.77.75A2.4,2.4,0,0,1,105,6.19a2.53,2.53,0,0,1-2.52,2.52A2.51,2.51,0,0,1,100.67,8a2.46,2.46,0,0,1-.76-1.79Zm.94,5.13h3.3V27h-3.3Z"/>
      </symbol>


      <symbol id="close" viewBox="0 0 30 30"><path d="M15 0c-8.3 0-15 6.7-15 15s6.7 15 15 15 15-6.7 15-15-6.7-15-15-15zm5.7 19.3c.4.4.4 1 0 1.4-.2.2-.4.3-.7.3s-.5-.1-.7-.3l-4.3-4.3-4.3 4.3c-.2.2-.4.3-.7.3s-.5-.1-.7-.3c-.4-.4-.4-1 0-1.4l4.3-4.3-4.3-4.3c-.4-.4-.4-1 0-1.4s1-.4 1.4 0l4.3 4.3 4.3-4.3c.4-.4 1-.4 1.4 0s.4 1 0 1.4l-4.3 4.3 4.3 4.3z"/></symbol>

      <symbol id="close-small" viewBox="0 0 11 11"><path d="M6.914 5.5l3.793-3.793c.391-.391.391-1.023 0-1.414s-1.023-.391-1.414 0l-3.793 3.793-3.793-3.793c-.391-.391-1.023-.391-1.414 0s-.391 1.023 0 1.414l3.793 3.793-3.793 3.793c-.391.391-.391 1.023 0 1.414.195.195.451.293.707.293s.512-.098.707-.293l3.793-3.793 3.793 3.793c.195.195.451.293.707.293s.512-.098.707-.293c.391-.391.391-1.023 0-1.414l-3.793-3.793z"/></symbol>

      <symbol id="arrow-left" viewBox="0 0 31 72"><path d="M30 72c-.3 0-.6-.1-.8-.4l-29-34c-.3-.4-.3-.9 0-1.3l29-36c.3-.4 1-.5 1.4-.2.4.3.5 1 .2 1.4l-28.5 35.5 28.5 33.4c.4.4.3 1.1-.1 1.4-.2.1-.5.2-.7.2z"/></symbol>

      <symbol id="arrow-right" viewBox="0 0 31 72"><path d="M1 0c.3 0 .6.1.8.4l29 34c.3.4.3.9 0 1.3l-29 36c-.3.4-1 .5-1.4.2-.4-.3-.5-1-.2-1.4l28.5-35.5-28.5-33.4c-.4-.4-.3-1.1.1-1.4.2-.1.5-.2.7-.2z"/></symbol>

      <symbol id="back" viewBox="0 0 20 20"><path d="M2.3 10.7l5 5c.4.4 1 .4 1.4 0s.4-1 0-1.4l-3.3-3.3h11.6c.6 0 1-.4 1-1s-.4-1-1-1h-11.6l3.3-3.3c.4-.4.4-1 0-1.4-.2-.2-.4-.3-.7-.3s-.5.1-.7.3l-5 5c-.2.2-.3.5-.3.7 0 .2.1.5.3.7z"/></symbol>

      <symbol id="menu" viewBox="0 0 22 22"><path d="M1 5h20c.6 0 1-.4 1-1s-.4-1-1-1h-20c-.6 0-1 .4-1 1s.4 1 1 1zm20 5h-20c-.6 0-1 .4-1 1s.4 1 1 1h20c.6 0 1-.4 1-1s-.4-1-1-1zm0 7h-20c-.6 0-1 .4-1 1s.4 1 1 1h20c.6 0 1-.4 1-1s-.4-1-1-1z"/></symbol>

      <symbol id="share" viewBox="0 0 22 22"><path d="M21 10c-.6 0-1 .4-1 1v7h-18v-7c0-.6-.4-1-1-1s-1 .4-1 1v7c0 1.1.9 2 2 2h18c1.1 0 2-.9 2-2v-7c0-.6-.4-1-1-1zM5.5 7.5c.3 0 .5-.1.7-.3l3.8-3.8v9.6c0 .6.4 1 1 1s1-.4 1-1v-9.6l3.8 3.8c.2.2.5.3.7.3s.5-.1.7-.3c.4-.4.4-1 0-1.4l-5.5-5.5c-.1-.1-.2-.2-.3-.2-.2-.1-.5-.1-.8 0l-.3.2-5.5 5.5c-.4.4-.4 1 0 1.4.2.2.4.3.7.3z"/></symbol>

      <symbol id="arrow-down" viewBox="0 0 24 24"><path d="M12 18c-.2 0-.5-.1-.7-.3l-11-10c-.4-.4-.4-1-.1-1.4.4-.4 1-.4 1.4-.1l10.4 9.4 10.3-9.4c.4-.4 1-.3 1.4.1.4.4.3 1-.1 1.4l-11 10c-.1.2-.4.3-.6.3z"/></symbol>

      <symbol id="arrow-up" viewBox="0 0 24 24"><path d="M11.9 5.9c.2 0 .5.1.7.3l11 10c.4.4.4 1 .1 1.4-.4.4-1 .4-1.4.1l-10.4-9.4-10.3 9.4c-.4.4-1 .3-1.4-.1-.4-.4-.3-1 .1-1.4l11-10c.1-.2.4-.3.6-.3z"/></symbol>

      <symbol id="arrow-top" viewBox="0 0 24 24"><path d="M20.7 10.3l-8-8c-.4-.4-1-.4-1.4 0l-8 8c-.4.4-.4 1 0 1.4s1 .4 1.4 0l6.3-6.3v15.6c0 .6.4 1 1 1s1-.4 1-1v-15.6l6.3 6.3c.2.2.5.3.7.3s.5-.1.7-.3c.4-.4.4-1 0-1.4z"/></symbol>

      <symbol id="drop-down" viewBox="0 0 16 16"><polyline stroke-width="2" stroke-linecap="round" stroke-linejoin="round" stroke-miterlimit="10" points="1,5 8,12 15,5" fill="none"></polyline></symbol>

      <symbol id="play" viewBox="0 0 30 30"><path d="M7 30v-30l22 15z"/></symbol>

      <symbol id="login" viewBox="0 0 22 22"><path d="M13 2c0 .6.4 1 1 1h6v16h-6c-.6 0-1 .4-1 1s.4 1 1 1h6c1.1 0 2-.9 2-2v-16c0-1.1-.9-2-2-2h-6c-.6 0-1 .4-1 1zm-6.5 3.5c0 .3.1.5.3.7l3.8 3.8h-9.6c-.6 0-1 .4-1 1s.4 1 1 1h9.6l-3.8 3.8c-.2.2-.3.5-.3.7s.1.5.3.7c.4.4 1 .4 1.4 0l5.5-5.5c.1-.1.2-.2.2-.3.1-.2.1-.5 0-.8l-.2-.3-5.5-5.5c-.4-.4-1-.4-1.4 0-.2.2-.3.4-.3.7z"/></symbol>

      <symbol id="chat" viewBox="0 0 22 22"><path d="M11 22c-.1 0-.3 0-.4-.1-.4-.1-.6-.5-.6-.9v-4h-7.8c-1.2 0-2.2-1-2.2-2.2v-11.6c0-1.2 1-2.2 2.2-2.2h17.7c1.1 0 2.1 1 2.1 2.2v11.7c0 1.2-1 2.2-2.2 2.2h-3.4l-4.7 4.7c-.2.1-.4.2-.7.2zm-8.8-19c-.1 0-.2.1-.2.2v11.7s.1.1.2.1h8.8c.6 0 1 .4 1 1v2.6l3.3-3.3c.2-.2.4-.3.7-.3h3.8c.1 0 .2-.1.2-.2v-11.6c0-.1-.1-.2-.2-.2h-17.6zM5 6h6v2h-6zM5 10h10v2h-10z"/></symbol>

      <symbol id="mail" viewBox="0 0 22 22"><path d="M19.8 2h-17.6c-1.2 0-2.2 1-2.2 2.2v13.5c0 1.3 1 2.3 2.2 2.3h17.5c1.2 0 2.2-1 2.2-2.2v-13.6c.1-1.2-.9-2.2-2.1-2.2zm-17.6 2h17.5c.2 0 .3.1.3.2v.3l-9 6.3-9-6.3v-.3c0-.1.1-.2.2-.2zm17.6 14h-17.6c-.1 0-.2-.1-.2-.2v-10.9l8.1 5.7c.3.2.6.3.9.3.3 0 .6-.1.9-.3l8.1-5.7v10.9c0 .1-.1.2-.2.2z"/></symbol>
    </svg>


        <!-- Top Menu -->
        <nav class="panel top fixed forceMobileView">
          <div class="sections desktop">
            <div class="left"><a href="/en/#" title="Coinomi"><img src="/svg/coinomi-logo-color.svg" alt="Coinomi Logo" class="coinomiLogoDesktop"></a></div>
            <div class="right">
              <ul class="menu">
                <li><a href="/en/about/">About</a></li>
                <li class="button button-dropdown"><a href="" class="dropdownTrigger" data-dropdown-id="shop-dropdown">
                    Exchange
                </a></li>
                <li><a href="https://shop.coinomi.com" target="_blank">Shop</a></li>
                <li><a href="https://support.coinomi.com/" target="_blank" rel="noopener noreferrer">Support</a></li>
                <li class="button button-dropdown bordered"><a href="" class="dropdownTrigger block" data-dropdown-id="lang-dropdown">
                  <svg
                    xmlns="http://www.w3.org/2000/svg"
                    viewBox="0 0 24 24"
                    aria-hidden="true"
                    class="icon icon-language"
                  >
                    <path fill="currentColor" d="M12,24C5.4,24,0,18.6,0,12S5.4,0,12,0s12,5.4,12,12S18.6,24,12,24z M9.5,17c0.6,3.1,1.7,5,2.5,5s1.9-1.9,2.5-5H9.5z M16.6,17c-0.3,1.7-0.8,3.3-1.4,4.5c2.3-0.8,4.3-2.4,5.5-4.5H16.6z M3.3,17c1.2,2.1,3.2,3.7,5.5,4.5c-0.6-1.2-1.1-2.8-1.4-4.5H3.3z M16.9,15h4.7c0.2-0.9,0.4-2,0.4-3s-0.2-2.1-0.5-3h-4.7c0.2,1,0.2,2,0.2,3S17,14,16.9,15z M9.2,15h5.7c0.1-0.9,0.2-1.9,0.2-3S15,9.9,14.9,9H9.2C9.1,9.9,9,10.9,9,12C9,13.1,9.1,14.1,9.2,15z M2.5,15h4.7c-0.1-1-0.1-2-0.1-3s0-2,0.1-3H2.5C2.2,9.9,2,11,2,12S2.2,14.1,2.5,15z M16.6,7h4.1c-1.2-2.1-3.2-3.7-5.5-4.5C15.8,3.7,16.3,5.3,16.6,7z M9.5,7h5.1c-0.6-3.1-1.7-5-2.5-5C11.3,2,10.1,3.9,9.5,7z M3.3,7h4.1c0.3-1.7,0.8-3.3,1.4-4.5C6.5,3.3,4.6,4.9,3.3,7z"/>
                  </svg>
                  Language
                </a></li>
              </ul>

              <a class="button black" href="/en/downloads/">Download</a>

            </div>
          </div>
          <div class="sections compact hidden">
            <div class="left"> <a href="/en/#" title="Coinomi"><svg class="coinomiLogoMobileTopBar"><use xmlns:xlink="http://www.w3.org/1999/xlink" xlink:href="#logo"></use></svg></a></div>
            <div class="right">
              <button href="#" class="button dropdownTrigger lang-dropdown" data-dropdown-id="lang-dropdown">
                <svg
                  xmlns="http://www.w3.org/2000/svg"
                  viewBox="0 0 24 24"
                  aria-hidden="true"
                  class="icon icon-language"
                >
                  <path fill="currentColor" d="M12,24C5.4,24,0,18.6,0,12S5.4,0,12,0s12,5.4,12,12S18.6,24,12,24z M9.5,17c0.6,3.1,1.7,5,2.5,5s1.9-1.9,2.5-5H9.5z M16.6,17c-0.3,1.7-0.8,3.3-1.4,4.5c2.3-0.8,4.3-2.4,5.5-4.5H16.6z M3.3,17c1.2,2.1,3.2,3.7,5.5,4.5c-0.6-1.2-1.1-2.8-1.4-4.5H3.3z M16.9,15h4.7c0.2-0.9,0.4-2,0.4-3s-0.2-2.1-0.5-3h-4.7c0.2,1,0.2,2,0.2,3S17,14,16.9,15z M9.2,15h5.7c0.1-0.9,0.2-1.9,0.2-3S15,9.9,14.9,9H9.2C9.1,9.9,9,10.9,9,12C9,13.1,9.1,14.1,9.2,15z M2.5,15h4.7c-0.1-1-0.1-2-0.1-3s0-2,0.1-3H2.5C2.2,9.9,2,11,2,12S2.2,14.1,2.5,15z M16.6,7h4.1c-1.2-2.1-3.2-3.7-5.5-4.5C15.8,3.7,16.3,5.3,16.6,7z M9.5,7h5.1c-0.6-3.1-1.7-5-2.5-5C11.3,2,10.1,3.9,9.5,7z M3.3,7h4.1c0.3-1.7,0.8-3.3,1.4-4.5C6.5,3.3,4.6,4.9,3.3,7z"/>
                </svg>
                Language
              </button>
              <span class="button actionButton sidebarTrigger" data-sidebar-id="1"><svg><use xmlns:xlink="http://www.w3.org/1999/xlink" xlink:href="#menu"></use></svg></span>
            </div>
          </div>
        </nav>

        <!-- Menu dropdown -->
        <div class="dropdown top left langDropdown z-1000" data-dropdown-id="shop-dropdown">
          <ul class="menu">
              <li><a href="/en/buy/simplex/">Buy Crypto</a></li>
              <li><a href="/en/sell/onramper/">Sell Crypto</a></li>
              <li><a href="/en/swap/">Swap Crypto</a></li>
          </ul>
        </div>

        <div class="dropdown top left langDropdown z-1000" data-dropdown-id="lang-dropdown">
          <ul class="menu">
            <li class="link">
              <a href="/en/404.mustache">English (en)</a>
            </li>
            <li class="link">
              <a href="/zh/404.mustache">中文 (zh)</a>
            </li>
            <li class="link">
              <a href="/es/404.mustache">Español (es)</a>
            </li>
            <li class="link">
              <a href="/ar/404.mustache">العربية (ar)</a>
            </li>
            <li class="link">
              <a href="/fr/404.mustache">Français (fr)</a>
            </li>
            <li class="link">
              <a href="/ru/404.mustache">Русский (ru)</a>
            </li>
            <li class="link">
              <a href="/de/404.mustache">Deutsch (de)</a>
            </li>
            <li class="link">
              <a href="/ja/404.mustache">日本語 (ja)</a>
            </li>
            <li class="link">
              <a href="/tr/404.mustache">Türkçe (tr)</a>
            </li>
            <li class="link">
              <a href="/uk/404.mustache">Українська (uk)</a>
            </li>
            <li class="link">
              <a href="/pl/404.mustache">Polski (pl)</a>
            </li>
            <li class="link">
              <a href="/el/404.mustache">Ελληνικά (el)</a>
            </li>
          </ul>
        </div>

        <!-- Sidebar (mobile menu) -->
        <nav class="sidebar blue" data-sidebar-id="1">
          <div class="close"><svg><use xmlns:xlink="http://www.w3.org/1999/xlink" xlink:href="#close"></use></svg></div>
          <div class="content">
            <a href="/" title="Coinomi" class="logo"><svg width="120" height="50"><use xmlns:xlink="http://www.w3.org/1999/xlink" xlink:href="#logo"></use></svg></a>

            <ul class="mainMenu">
              <li><a href="/en/about/">About</a></li>
              <li><a href="/en/downloads/">Download</a></li>
              <li><a href="/en/buy/simplex/">Buy Crypto</a></li>
              <li><a href="/en/sell/onramper/">Sell Crypto</a></li>
              <li><a href="/en/swap/">Swap Crypto</a></li>
              <li><a href="https://shop.coinomi.com" target="_blank">Shop</a></li>
            </ul>
            <ul class="subMenu">
              <li><a href="/en/#why">Why Coinomi?</a></li>
              <li><a href="/en/#features">Features</a></li>
              <li><a href="/en/assets/">Assets</a></li>
            </ul>
            <ul class="subMenu tiny">
              <li><a href="http://support.coinomi.com" target="_blank" rel="noopener noreferrer">Support</a></li>
              <li><a href="/en/careers/">Careers</a></li>
              <li><a href="/en/contact/">Contact</a></li>
              <li><a href="/en/terms/">Terms of use</a></li>
              <li><a href="/en/privacy/">Privacy policy</a></li>
              <li><a href="/en/responsible-disclosure/">Responsible Disclosure</a></li>
            </ul>

          </div>
        </nav>
    <!-- Cookie dialog -->
    <!-- <div class="dialogContainer bottom left">
      <div class="dialog" data-dialog-id="cookies" data-set-cookie="30">
        <div class="close" data-dialog-action="hide"></div>
        <div class="dialogContent">
          <img width="50" class="avatar" src="/svg/cookie.svg" alt="Cookie Icon">
          <div class="text">
            We use cookies to better provide our services. By using our services, you agree to our use of cookies.
          </div>
        </div>
        <ul>
          <li data-href="/privacy/" title="Privacy policy">More info</li>
          <li data-dialog-action="close" class="blue">OK</li>
        </ul>
      </div>
    </div> -->

    <section class="slide autoHeight coinomi-terms">
      <div class="content">
        <div class="container">
          <div class="wrap">
            <div class="fix-10-12 left">

              <svg version="1.1" viewBox="0 0 24 24" xmlns="http://www.w3.org/2000/svg" xmlns:xlink="http://www.w3.org/1999/xlink" width="240">
                  <!--Generated by IJSVG (https://github.com/iconjar/IJSVG)-->
                  <g stroke-linecap="round" stroke-width="1" stroke="#fff" fill="none" stroke-linejoin="round">
                      <path d="M23.5,18.5c0,1.105 -0.895,2 -2,2h-19c-1.104,0 -2,-0.895 -2,-2v-14c0,-1.104 0.896,-2 2,-2h19c1.105,0 2,0.896 2,2v14Z"></path>
                      <path d="M0.5,7.5h23"></path>
                      <path d="M4.35355,4.64645c0.195262,0.195262 0.195262,0.511845 0,0.707107c-0.195262,0.195262 -0.511845,0.195262 -0.707107,0c-0.195262,-0.195262 -0.195262,-0.511845 0,-0.707107c0.195262,-0.195262 0.511845,-0.195262 0.707107,0"></path>
                      <path d="M7.35355,4.64645c0.195262,0.195262 0.195262,0.511845 0,0.707107c-0.195262,0.195262 -0.511845,0.195262 -0.707107,0c-0.195262,-0.195262 -0.195262,-0.511845 0,-0.707107c0.195262,-0.195262 0.511845,-0.195262 0.707107,0"></path>
                      <path d="M10.3536,4.64645c0.195262,0.195262 0.195262,0.511845 0,0.707107c-0.195262,0.195262 -0.511845,0.195262 -0.707107,0c-0.195262,-0.195262 -0.195262,-0.511845 0,-0.707107c0.195262,-0.195262 0.511845,-0.195262 0.707107,0"></path>
                      <path d="M13.416,14.053c0,1.381 -0.19,2.5 -1.276,2.5c-1.087,0 -1.276,-1.119 -1.276,-2.5c0,-1.381 0.189,-2.5 1.276,-2.5c1.086,0 1.276,1.119 1.276,2.5Z"></path>
                      <path d="M8.5,16.5v-4.895l-2.053,2.895h2.553"></path>
                      <path d="M17.5,16.5v-4.895l-2.053,2.895h2.553"></path>
                  </g>
                  <path fill="none" d="M0,0h24v24h-24Z"></path>
              </svg>

              <h1>Page not found</h1>
              <div class="accent sub white"></div>
              <div>


                <h2 class="hero">
                Error 404
                </h2>
                <p class="big">
                  The specified file was not found on this website.<br> Please check the URL and try again.

                </p>

              </div>
            </div>
          </div>
        </div>
      </div>
      <div class="background red">
    </section>


        <section class="slide whiteSlide autoHeight coinomi-footer exclude" data-title="Footer" data-parent-slide-id="4">
          <div class="content">
            <div class="container">
              <div class="wrap">

                <div class="fix-12-12">
                  <ul class="grid fixedSpaces left">
                    <li class="col-2-12 col-tablet-1-1 padding-bottom-2 ae-1">
                      <a href="/en/#" class="logo"><svg width="120" height="50"><use xmlns:xlink="http://www.w3.org/1999/xlink" xlink:href="#logo"></use></svg></a>
                    </li>
                    <li class="col-2-12 col-tablet-1-2 col-phone-1-1 ae-2">
                      <h3 class="margin-bottom-1 text-lime">Learn</h3>
                      <p class="micro"><a href="/en/#why">Why Coinomi?</a></p>
                      <p class="micro"><a href="/en/#features">Features</a></p>
                      <p class="micro"><a href="/en/assets/">Assets</a></p>
                     </li>
                    <li class="col-2-12 col-tablet-1-2 col-phone-1-1 ae-2">
                      <h3 class="margin-bottom-1 text-orange">Company</h3>
                      <p class="micro"><a href="/en/about/">About</a></p>
                      <p class="micro"><a href="/en/careers/">Careers</a></p>
                      <p class="micro"><a href="https://downloads.coinomi.com/files/Coinomi-Brand-Assets.zip">Brand Assets</a></p>
                      <p class="micro"><a href="/en/contact/">Contact</a></p>
                    </li>
                    <li class="col-2-12 col-tablet-1-2 col-phone-1-1 ae-3">
                      <h3 class="margin-bottom-1 text-teal">Community</h3>
                      <p class="micro"><a href="https://support.coinomi.com" target="_blank" rel="noopener noreferrer">Help &amp; Support</a></p>
                      <p class="micro"><a href="https://coinomi.featureupvote.com" target="_blank" rel="noopener noreferrer">Feature Request</a></p>
                      <p class="micro"><a href="https://coinomi.github.io/tools/" target="_blank" rel="noopener noreferrer">Tools</a></p>
                      <p class="micro"><a href="https://www.youtube.com/channel/UC4tA_slGgx1O-aClJF_Ufjw/featured" target="_blank" rel="noopener noreferrer">YouTube</a></p>
                      <p class="micro"><a href="https://github.com/coinomi/" target="_blank" rel="noopener noreferrer">Github</a></p>
                      <p class="micro"><a href="https://www.linkedin.com/company/coinomi/" target="_blank" rel="noopener noreferrer">LinkedIn</a></p>
                    </li>
                    <li class="col-2-12 col-tablet-1-2 col-phone-1-1 ae-4">
                      <h3 class="margin-bottom-1 text-purple">Social</h3>
                      <p class="micro"><a href="https://x.com/coinomiwallet" target="_blank" rel="noopener noreferrer">X</a></p>
                      <p class="micro"><a href="https://t.me/coinomi_official" target="_blank" rel="noopener noreferrer">Telegram</a></p>
                      <p class="micro"><a href="https://www.reddit.com/r/COINOMI/" target="_blank" rel="noopener noreferrer">Reddit</a></p>
                      <p class="micro"><a href="https://www.facebook.com/coinomi/" target="_blank" rel="noopener noreferrer">Facebook</a></p>
                      <p class="micro"><a href="https://www.instagram.com/coinomiofficial/" target="_blank" rel="noopener noreferrer">Instagram</a></p>
                      <p class="micro"><a href="https://medium.com/coinomi" target="_blank" rel="noopener noreferrer">Medium</a></p>
                    </li>
                    
                    <li class="col-2-12 col-tablet-1-2 col-phone-1-1 ae-5">
                      <h3 class="margin-bottom-1 text-blue"><a href="/downloads/">Downloads</a></h3>
                      <p class="micro"><a href="https://play.google.com/store/apps/details?id=com.coinomi.wallet" target="_blank" rel="noopener noreferrer">Android</a></p>
                      <p class="micro"><a href="https://itunes.apple.com/app/coinomi-wallet/id1333588809" target="_blank" rel="noopener noreferrer">iOS</a></p>
                      <p class="micro"><a href="/downloads/">Windows</a></p>
                      <p class="micro"><a href="/downloads/">macOS</a></p>
                      <p class="micro"><a href="/downloads/">Linux</a></p>
                    </li>

                  </ul>
                </div>
              </div>
            </div>
          </div>
        </section>

        <nav class="panel bottom forceMobileView">
          <div class="sections desktop">
            <div class="left">
              <ul class="menu uppercase">
                <li><span class="text coinomi-copyright"></li>
              </ul>
            </div>
            <div class="center">
            </div>
            <div class="right">
              <p class="micro "><a href="/en/terms/">Terms of use</a> <span class="divider">|</span> <a href="/en/privacy/">Privacy policy</a> <span class="divider">|</span> <a href="/en/responsible-disclosure/">Responsible Disclosure</a></p>
            </div>
          </div>
          <div class="sections compact hidden">
            <div class="left"><p class="micro coinomi-copyright"></p>
            </div>
            <div class="right"><span class="button actionButton toFirstSlide"><svg><use xmlns:xlink="http://www.w3.org/1999/xlink" xlink:href="#arrow-top"></use></svg></span>
            </div>
          </div>
        </nav>

        <!-- Preloader -->
        <div class="loadingIcon"><svg class="loading-icon" id="loading-circle" viewBox="0 0 18 18"><circle class="circle" opacity=".1" stroke="#000" stroke-width="2" stroke-miterlimit="10" cx="9" cy="9" r="8" fill="none"></circle><circle class="dash" stroke-width="2" stroke-linecap="round" stroke-miterlimit="10" stroke-dasharray="1,100" cx="9" cy="9" r="8" fill="none"></circle></svg></div>

  <script type="module" src="https://static.cloudflareinsights.com/beacon.min.js/v4513226cdae34746b4dedf0b4dfa099e1781791509496" integrity="sha512-ZE9pZaUXND66v380QUtch/5sE9tPFh2zg45pR2PB0CVkCtOREv2AJKkSidISWkysEuQ0EH8faUU5du78bx87UQ==" data-cf-beacon='{"version":"2024.11.0","token":"8b7218a0db9b4cdb91866002c4cfb720","r":1}' crossorigin="anonymous"></script>
</body>
</html>
